﻿#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <queue>

using namespace std;


bool in(int elem, vector<int> l) {
    for (int i = 0; i < l.size(); ++i)
        if (elem == l[i])
            return true;
    return false;
}

void search_min(int& weight, int& ind, vector<vector<int>> matrix, vector<int> visited, vector<int>& pred) {
    weight = INT_MAX;
  
    for (int i : visited) 
        for (int j = 0; j < matrix[i].size(); ++j) 
            if (matrix[i][j] > -1 && matrix[i][j] < weight && !in(j, visited)) {
                weight = matrix[i][j];
                ind = j;
                pred[ind] = i;
            }
}

vector<int> prim(vector<vector<int>> matrix, vector<int>& visited, vector<int>& pred) {
    visited = { 0 };
    vector<int> result = {};
    int weight, ind;

    for (int i = 1; i < matrix.size(); i++) {
        search_min(weight, ind, matrix, visited, pred);
        result.push_back(weight);
        visited.push_back(ind);

    }

    return result;
}

int get_distance(string fl1, string fl2) {
    int count = 0;
    for (int i = 0; i < fl1.size(); ++i)
        if (fl1[i] != fl2[i])
            count++;
    return count;
}

vector<vector<int>> read_file(int& n, int& m, int& k, int& w, vector<string>& floors, string in_filename) {
    string line, line1, line2 = "";
    bool flag = true;
    vector<int> vars;
    int counter = 0;

    ifstream in(in_filename);
    if (in.is_open())
        while (getline(in, line)) {
            if (flag) {
                stringstream streamData(line);
                const char separator = ' ';

                while (getline(streamData, line1, separator))
                    vars.push_back(stoi(line1));
                n = vars[0]; m = vars[1]; k = vars[2]; w = vars[3];
                flag = false;
            }
            else {
                counter++;
                line2 += line;
                if (counter % n == 0) {
                    floors.push_back(line2);
                    line2 = "";
                }
            } 
        }
    in.close();

    vector<vector<int>> matrix(k + 1, vector<int>(k + 1, -1));

    for (int i = 0; i < k + 1; i++)
        for (int j = 0; j < k + 1; j++)
            if ((i == 0 || j == 0) && i != j)
                matrix[i][j] = n * m;
            else if (i != j) {
                matrix[i][j] = get_distance(floors[i-1], floors[j-1])*w;
            }

    return matrix;
}

int vec_sum(vector<int> v) {
    int sum = 0;
    for (int i = 0; i < v.size(); i++)
        sum += v[i];
    return sum;
}

int main(int argc, char* argv[]) {
    string input, output;
    //string input ="input1.txt", output="output.txt";
    if (argc > 1) {
        input = argv[1];
        output = argv[2];
        int n, m, k, w;
        vector<string> floors;
        vector<vector<int>> matrix = read_file(n, m, k, w, floors, input);
        vector<int> visited;
        vector<int> pred(k + 1, -1);
        vector<int> p = prim(matrix, visited, pred);


        ofstream out;
        out.open(output);
        out << vec_sum(p) << "\n";
        for (int i = 1; i < visited.size(); i++) {
            int first, second;
            first = visited[i];
            second = pred[visited[i]];

            out << first << " " << second << endl;
        }

   }
}
